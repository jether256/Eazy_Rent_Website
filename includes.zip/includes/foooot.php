
<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:0705195464"><i class="fas fa-phone"></i><span>0705195464</span></a>
         <a href="tel:0778316724"><i class="fas fa-phone"></i><span>0778316724</span></a>
         <a href="mailto:eazyrent256@gmail.com"><i class="fas fa-envelope"></i><span>eazyrent256@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>Kampala</span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>home</span></a>
         <a href="about.php"><span>about</span></a>
         <a href="contact.php"><span>contact</span></a>
         <a href="listings.php"><span>all listings</span></a>
         
      </div>

      <div class="box">
         <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ 2023 by <span>Mutale Jether</span> | all rights reserved!</div>

</footer>

<!-- footer section ends --